<template>
    <div class="gallery">
        <imageItem v-for="(image, index) in images" v-on:click.native='clicked(index)' v-bind:imageURL="image"/>


        <div id="myModal" class="modal">
            <div class="modal-content">
                <imageWBBItem id="imageBigShow" v-bind:imageURL="this.images[this.index].url" v-bind:faces="this.faces" />
            </div>
            <span class="close" id="closeImageButton">&times;</span>
        </div>

 
    </div>
</template>

<script type="text/javascript">
    $(document).ready(function () {
        $("gallery").click(function () {
            $('#myModal').modal('show');
        });
    });
</script>

<script>
    import imageItem from './imageItem.vue';
    import imageWBBItem from './imageWBBItem';
    import axios from 'axios';

    window.onload = function() { 
        var modal = document.getElementById('myModal');

        var span = document.getElementById('closeImageButton'); 
        console.log(this.images);
        span.onclick = function() {
            modal.style.display = "none";
        }
    }

    export default {
        name: 'gallery',
        components: {
            imageItem,
            imageWBBItem
        },
        props: {
            images: {
              type: Array,
              default () {
                  return [];
              }
            },
        },
        data() {
            return {
                index: null,
                imagenowURL: '',
                faces: []
            };
        },
        watch: {
            index(value) {
                this.imagenowURL = this.images[value];
            },
        },
        methods: {
            clicked(index) {
                this.index = index;
                console.log(index);
                var modal = document.getElementById('myModal');
                axios.get('/api/face/' + String(this.images[this.index].id) + '/', {headers: {Authorization: "Token " + localStorage.token}}).then(function (response) {
                    this.faces = response.data.token;
                }).catch(function (error) {
                 console.log(error); 
                });
                modal.style.display = "block";
            },
        }
    }
</script>

<style>
    .gallery {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-around;
        margin: 10px;
    }

    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        padding-top: 100px; /* Location of the box */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
    }

    /* Modal Content (Image) */
    .modal-content {
        display: flex;
        justify-content: space-around;
        align-content: center;
        width: 80%;
        height: 100%;
        background-color: rgba(1, 1, 1, 0) !important;
        color: blue;

    }
    
    /* Add Animation - Zoom in the Modal */
    .modal-content { 
        animation-name: zoom;
        animation-duration: 0.6s;
    }

    @keyframes zoom {
        from {transform:scale(0)} 
        to {transform:scale(1)}
    }

    /* The Close Button */
    .close {
        position: absolute;
        top: 15px;
        right: 35px;
        color: #FFFFFF !important;
        font-size: 40px;
        font-weight: bold;
        transition: 0.3s;
    }

    .close:hover,
    .close:focus {
        color: #bbb;
        text-decoration: none;
        cursor: pointer;
    }
</style>