<template>
	<div>
    	<img id="imageWBBItem" v-bind:src="imageURL" alt=""/>
	</div>
</template>

<script>
	export default {
		name: 'imageWBBItem',
		props: ['imageURL'],
		methods: {}
	}
</script>

<style scoped>
    #imageWBBItem {
        margin: auto;
        overflow: auto;
        display: block;
    }
</style>